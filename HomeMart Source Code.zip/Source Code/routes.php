<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('hello', function()
{
    return 'Hello World!';
});

Route::get('show', array('uses'=>'show@get_index'));
Route::get('showall',array('uses'=>'showall@get_index'));
Route::post('create',array('uses'=>'create@createRecord'));
Route::post('create/{id}',array('uses'=>'create@updateRecord'));


Route::get('delete/{id}',array('uses'=>'delete@deleteit'));
Route::get('deletelisting/{id}',array('uses'=>'deletelisting@deletelisting'));

//Route::get('edit/{id}',array('uses'=>'showall@get_index2'));


Route::get('home', function () {
    return view('login');
});

Route::get('placed', function () {
    return view('placed');
});

Route::get('contact', function () {
    return view('contact');
});
Route::get('register', function(){
	
	return view('register');
	});	
	
	Route::get('getproducts/{cid}',array('uses'=>'allproducts@get_products'));
Route::get('getcart/{cid}',array('uses'=>'getcart@get_cart'));
Route::get('deletecart/{id}/{cid}',array('uses'=>'deletecart@deleteit'));
Route::get('addtocart/{pid}/{cid}',array('uses'=>'addtocart@add'));
	
	Route::post('auth',array('uses'=>'auth@checkAuth'));
Route::post('register',array('uses'=>'register@registerCustomer'));
Route::get('edit/{id}',array('uses'=>'edit@get_index2'));
Route::post('register/{id}',array('uses'=>'register@updateRecord'));

