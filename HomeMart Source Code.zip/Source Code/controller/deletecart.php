<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\DB;

class deletecart extends Controller
{
    //
	public function deleteit($id,$cid){
		
		//return $id;
		
		DB::delete("delete from orders where (prodid=$id and custid=$cid)");
		return 'deleted';
		
		
		
		}
}
