<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\DB;

class edit extends Controller
{
    //
	public function get_index2($id){
		
		$users = DB::table('customer')
		->where('id','=', $id)
		->get();
		
		$view = View::make('register2');
	    $view->homemart = json_encode($users);
		
		return $view;
		
		}
}
