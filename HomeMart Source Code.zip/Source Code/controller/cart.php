<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\DB;

class allproducts extends Controller
{
    //
	public function get_cart($id){
		
		$users = DB::table('orders')
		->where('custid','=',$id)
		->orderBy('id', 'desc')
		->get();
		
		//$view = View::make('index');
		//$view->arihant = json_encode($users);
		
		return $users;
		
		}
}
