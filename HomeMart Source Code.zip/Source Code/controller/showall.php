<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\DB;

class showall extends Controller
{
    //
	public function get_index(){
		
		$users = DB::table('records')
		->orderBy('id', 'desc')
		->get();
		
		$view = View::make('index');
		$view->arihant = json_encode($users);
		
		return $view;
		
		}
		
		
		public function get_index2($id){
		
		$users = DB::table('records')
		->where('id','=', $id)
		->get();
		
		$view = View::make('index2');
		$view->arihant = json_encode($users);
		
		return $view;
		
		}
		
}
