<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\DB;
use App\Http\Requests;



use \App\customer;
use App\Http\Controllers\Controller;

class register extends Controller
{
    //
	public function registerCustomer(Request $request){
		
		  $users = DB::select("SELECT `AUTO_INCREMENT` FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'mydb' AND TABLE_NAME = 'customer'");
 $aid=$users[0]->AUTO_INCREMENT;
		
		
	 json_decode($request->getContent(), true);
	 //return $request;
	 $list = new customer;

$list->custid = ''.$aid;
$list->firstname =''.$request->firstname;
$list->lastname =''.$request->lastname;
$list->address =''.$request->address;
$list->email =''.$request->email;
$list->phone =''.$request->phone;
$key =  $request->email.$request->password;
$lowerKey = strtolower($key);
$hash = md5($lowerKey);
$list->hashkey =''.$hash;

$list->save();
//return $hash;
$result=array();
array_push($result,$aid);
	 
return json_encode($result);
	}

	public function updateRecord(Request $request, $id){
		 json_decode($request->getContent(), true);
	 	 
		 $update = customer::find($id);
		 
$update->firstname = ''.$request->firstname;// Input::get('username');
$update->lastname =''.$request->lastname;
$update->email =''.$request->email;
$update->phone =''.$request->phone;
$update->address =''.$request->address;
$key =  $request->email.$request->password;
$lowerKey = strtolower($key);
$hash = md5($lowerKey);
$update->hashkey =''.$hash;
$update->save();
		 
		 return json_encode($update);
		 	
		}
	
	
	
}
