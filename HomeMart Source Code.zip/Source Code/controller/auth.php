<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\DB;
use App\Http\Requests;



use \App\customer;
use App\Http\Controllers\Controller;

class auth extends Controller
{
    
	public function checkAuth(Request $request){
	 json_decode($request->getContent(), true);
	 $key =  $request->email.$request->password;
	 $lowerKey = strtolower($key);
	 $hash = md5($lowerKey);
	 
	 $result= DB::table('customer')->where('hashkey', '=', $hash)->get();
	 
	 
return json_encode($result);

	}
	
	
}
