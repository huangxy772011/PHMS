<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\DB;

class deletelisting extends Controller
{
    //
	public function deletelisting($id){
		
		//return $id;
		
		DB::table('products')->where('prodid', '=', $id)->delete();
		return 'deleted';
		
		
		
		}
}
