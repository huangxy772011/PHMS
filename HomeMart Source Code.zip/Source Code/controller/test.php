<?php

namespace App\Http\Controllers;

use \App\Records;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class test extends Controller
{
    //
	public function add(Request $request){
		$list = new Records;

$list->product ='arihant';// Input::get('username');
$list->name ='arihant';
$list->email ='arihant';
$list->phone ='234234';
$list->cost ='234';
$list->description ='arihant';
$list->category ='arihant';
$list->date ='234';
$list->image ='arihant';

$list->save();
		}
}
