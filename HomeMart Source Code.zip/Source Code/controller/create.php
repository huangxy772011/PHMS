<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\DB;
use App\Http\Requests;



use \App\Records;
use App\Http\Controllers\Controller;

class create extends Controller
{
    //
	public function createRecord(Request $request){
	 json_decode($request->getContent(), true);
	 //return $request;
	 $list = new Records;

$list->product = ''.$request->pname;// Input::get('username');
$list->name =''.$request->fname;
$list->email =''.$request->email;
$list->phone =''.$request->phone;
$list->cost =''.$request->price;
$list->description =''.$request->description2;
$list->category =''.$request->category;
$list->date =''.$request->date22;
$list->image ='default.jpg';
$list->save();

$result=array();
array_push($result,'Listing Added!');
	 
return json_encode($result);
	}
	
	public function updateRecord(Request $request, $id){
		 json_decode($request->getContent(), true);
	 	 
		 $update = Records::find($id);
$update->product = ''.$request->pname;// Input::get('username');
$update->name =''.$request->fname;
$update->email =''.$request->email;
$update->phone =''.$request->phone;
$update->cost =''.$request->price;
$update->description =''.$request->description2;
$update->category =''.$request->category;
$update->date =''.$request->date22;
$update->image ='default.jpg';
$update->save();
		 
		 return 'updated';
		 	
		}
	
	
	
}
