<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\DB;

class getcart extends Controller
{
    //
	public function get_cart($cid){
		$mainarray=array();
		$users = DB::table('orders')
		->where('custid','=', $cid)
		->orderBy('id', 'desc')
		->get();

$arr = json_decode(json_encode((array) $users), true);
		//$arr = json_decode($users[0],TRUE);
		//print_r( $arr);
		
		//$users = DB::select('select * from products', [1]);
		for($i=0;$i<count($arr);$i++){
			
			$users2 = DB::table('products')
		->where('prodid','=', $arr[$i]['prodid'])
		->get();
			array_push($mainarray, json_decode(json_encode((array) $users2), true));
			}/*json_decode($users2,true*/
			$view = View::make('cart');
		    $view->cart = json_encode($mainarray);
		    $view->custid=$cid;
		return $view;
			
		}
}
