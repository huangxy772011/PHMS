<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\DB;

class delete extends Controller
{
    //
	public function deleteit($id){
		
		//return $id;
		
		DB::table('records')->where('id', '=', $id)->delete();
		return 'deleted';
		
		
		
		}
}
