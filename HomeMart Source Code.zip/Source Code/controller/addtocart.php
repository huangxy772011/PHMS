<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\DB;
use App\Http\Requests;

use \App\orders;
use App\Http\Controllers\Controller;



class addtocart extends Controller
{
    //
	public function add($pid,$cid){
		
$list = new orders;
$list->prodid = $pid;
$list->custid =$cid;
$list->save();

return 'added';
		
		}
}
