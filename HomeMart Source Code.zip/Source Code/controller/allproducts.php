<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\DB;

class allproducts extends Controller
{
    //
	public function get_products($cid){
		
		$users = DB::table('products')
		->orderBy('id', 'desc')
		->get();
		
		$view = View::make('index_products');
		$view->products = json_encode($users);
		$view->cid=$cid;
		
		return $view;
		
		}
}
