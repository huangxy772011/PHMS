<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Colonialist | George Washington University</title>
	<link rel="stylesheet" type="text/css" href="http://www.webcase.in/lab/css/reset.css">
	<link rel="stylesheet" type="text/css" href="http://www.webcase.in/lab/css/main_responsive.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="http://www.webcase.in/lab/js/jquery.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script type="text/javascript" src="http://www.webcase.in/lab/js/main.js"></script>
     <meta name="_token" content="{!! csrf_token() !!}"/>
</head>

<body>
<header>
		<div class="wrapper">
			<img src="http://www.webcase.in/lab/img/logo.png" alt="GWU" class="logo" height="60">
			<a href="#" class="menu_icon" id="menu_icon"></a>
			<nav id="nav_menu">
				<ul>
					<li><a href="index.html">Home</a></li>
					<li><a href="post.html">Post a Classified</a></li>
					<li><a href="view.php">View Products</a></li>
					<li><a href="#">Contact</a></li>
				</ul>
			</nav>

			<ul class="social">
				<li><a class="fb" href="https://www.facebook.com/georgewashingtonuniversity"></a></li>
				<li><a class="twitter" href="https://twitter.com/GWtweets"></a></li>
			</ul>
	  </div>
	</header><!--  End Header  -->

	<section class="billboard">
			<div class="wrapper">
				<div class="caption">
					<p>George Washington University</p>
					<p>Colonialist</p>
                    <p>Classified Ads for Colonials</p>
				</div>
			</div>
	</section>
<section class="cta">
		<h3>Post a classified</h3>
		<p>* fields are required</p>
        
        
        <script type="text/javascript">
        // pass PHP variable declared in above file to JavaScript variable
        var json = <?php echo $arihant ?>;
		console.log(json);
        </script>

         <div class="form"><form name="myForm" id="myForm"  onsubmit="return validate()" method="post" enctype="multipart/form-data">
        
           <p>Product or Service Name*<br />
           <script type="text/javascript">
            document.write('<input id="pname" type="text" name="pname" class="inputField" placeholder="Product or Service Name" value="' + json[0].product + '"/></p>');
		   </script>
           <p>          Name* <br>
          <script type="text/javascript">     
           document.write('<input id="fname" type="text" name="fname" class="inputField" placeholder="Enter Name" value="' + json[0].name + '"/></p>');</script>
           <p>Email*<br>
            <script type="text/javascript">   
          document.write('<input id="email" type="email" name="email" class="inputField" placeholder="example@abcd.com" value="' + json[0].email + '"/></p>');</script>
           <p>
            Phone*<br>
			 <script type="text/javascript">
           document.write('<input id="phone" type="number" name="phone" class="inputField" placeholder="9876543210" value="' + json[0].phone + '"/></p>');</script>
           <p>Cost*<br>
		    <script type="text/javascript">
            document.write('<input id="price" type="number" name="price" class="inputField" placeholder="Enter Numeric Cost" value="' + json[0].cost + '"/></p>');</script>
           <p>Description*<br>
		   
             <label for="description"></label>
			  <script type="text/javascript">
             document.write('<textarea name="description2" class="inputField" id="description" placeholder="Add description">'+json[0].description+'</textarea></p>');
		   </script>
          <p>Category*<br>
             <label for="category"></label>
             <select name="category" class="inputField" id="category" style="width:200px">
               <option value="apartments">Apartments</option>
               <option value="electronics">Electronics</option>
               <option value="oncampusjobs">On-Campus Jobs</option>
               <option value="furniture">Furniture</option>
               <option value="books">Books</option>
               <option value="carpool">Carpool</option>
               <option value="parking">Parking</option>
               <option value="tickets">Tickets</option>
               <option value="others">Others</option>
             </select>
           </p>
           <p> Date*<br>
           <script type="text/javascript">
document.write('<input type="date" id="date22" name="date22" class="inputField" style="width:200px" value="'+json[0].date+'"/></p>');
</script>
           <p>Image:</p>
             <script type="text/javascript">
             document.write('<input type="file" name="pic" accept="image/*" value="'+json[0].pic+'" />');
             </script>
			 <br/>
            
             <button   type="button" class=" button" id="12" value="Submit"> SUBMIT </button>
             <br>
           </p>
         </form>
        </div>
    <div id="result"></div>
    
 <script type="text/javascript">   
    
   $("#12").click(function(){
	   $.ajaxSetup({
   headers: { 'X-CSRF-Token' : $('meta[name=_token]').attr('content') }
});
		 $.post("../create/"+json[0].id, $("#myForm").serialize(), function(data) {
if(data=='updated'){
	alert('Listing with ID '+ json[0].id + ' has been updated');
	location.replace("/laravel/showall");
	}

 });	
		});  
    

 
 </script>   
	</section>

	<footer>
		<img src="http://www.webcase.in/lab/img/logo.png" alt="GWU Colonialist">
		<p class="rights">Copyright © Colonialist - <a href="http://www.webcase.in">Developed by Arihant Jain - Other Projects by me (WebCase)</a></p>
	</footer><!--  End Footer  -->
</body>
</html>