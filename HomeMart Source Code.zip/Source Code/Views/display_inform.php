<?php 
// Getting ID of listing

$id=50;
//stripslashes(htmlentities($_GET['id']));
if(is_numeric($id)){
// Connection File
require'connection.php';

// Query to select details of particular product ID
  $query = "SELECT * FROM records where id=$id";
  $result = $conn->query($query);
  $rows = array();
// Looping through results
  $numrows = $result->num_rows;
while ($row = $result->fetch_assoc()){
 $rows[] = $row;
 
   $id=$row['id'];
   $name=$row['name'];
  $product=$row['product'];
  $date=$row['date'];
  $email=$row['email'];
  $phone=$row['phone'];
  $description=$row['description'];
  $cost=$row['cost'];
  $category=$row['category'];
  $image=$row['image'];
  
  $year = substr($date,0, 4);
  $month = substr($date,4,2);
   $date1 = substr($date,6,8);
   
   $finaldate=$year.'-'.$month.'-'.$date1;
   
   $post_data = array(
  'listing' => array(
    'id' => $id,
    'name' => $name,
    'product' => $product,
    'email' => $email,
    'phone' => $phone,
    'description' => $description,
   'cost' => $cost,
    'category' => $category,
   'date' => $date 
  )
);
	$json_object=json_encode($post_data); 
	 
echo '<div style="text-align:left">';
echo '<pre>';
echo '<strong>Incoming JSON object to prepopulate form</strong><br/>';
echo  json_encode($post_data);
echo '</div>';	 
  

  
    
 
 }
}
else{
	echo'<span style="color:red; font-size: 36px; font-weight:bold;">Suspicious activity detected. Data will not be updated.</span>';
	}

?>
