<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/js-cookie/2.1.3/js.cookie.min.js"></script>
   <link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
  <script
  src="https://code.jquery.com/jquery-3.1.1.min.js"
  integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  crossorigin="anonymous"></script>
	<meta charset="utf-8" />
	<title>Products</title>
      <script type="text/javascript">
  var json=<?php echo $products ?>;
  var cid=<?php echo $cid ?>;
  console.log(json);
  var c=Cookies.get('id');
  var access=Cookies.get('access');
  var cartitem=0;
 
  
  
  
  </script>
  <style>
  td{
	  text-align:center;}
	.product{
		width:200px;
		margin-left:2%;
		margin-top:10px;
		float:left;
		border-style: solid;
    border-width: 1px; 
	border-color:#CCC;
	padding:10px;
		}  
	.cartbutton{
		width:100%;
		height:20px;
		text-align:center;
		color:white;
		background-color:green;
		border:none;
		margin-top:5px; 
		font-family:Tahoma, Geneva, sans-serif;
		}
		
	.deletebutton{
		width:100%;
		height:20px;
		text-align:center;
		color:white;
		background-color:red;
		border:none;
		margin-top:5px; 
		font-family:Tahoma, Geneva, sans-serif;
		}	
		td{
			font-family: "Tahoma", Geneva, sans-serif;
			text-decoration:none;
			}
		a:link {
    text-decoration: none;
	color:#09F;
}

a:visited {
    text-decoration: none;
	color:#09F;
}

a:hover {
    text-decoration: underline;
}

a:active {
    text-decoration: underline;
}
body{
	font-family:Tahoma, Geneva, sans-serif;
	}
		
  </style>
  </head>
<body>
	<h1 align="center" style="font-family: 'Lobster', cursive;"><span style="color:#06F">Home</span><span style="color:#0C3">Mart</span></h1>
    <center>Local produce, Delivered.</center>
	<hr color=grey SIZE=1/>
    
    
   <div id="nav"><table width="100%" border="0" cellspacing="1" cellpadding="1">
  <tr>
    <td><a href="/laravel/home">HOME</a></td>
    <td id="p"><script type="text/javascript">
    document.getElementById('p').innerHTML='<a href="../getproducts/'+c+'">PRODUCTS</a>';
    </script></td>
    <td id="cid"><script type="text/javascript">
    document.getElementById('cid').innerHTML='<a href="../getcart/'+c+'">CART</a>';
    </script></td>
    <td><a href="/laravel/contact">CONTACT</a></td>
    <td><div id="update"><script type="text/javascript"> document.getElementById('update').innerHTML='<a href="../edit/'+c+'">UPDATE PROFILE</a>';</script></td>
    <td><div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.8&appId=370203893082428";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div class="fb-like" data-href="https://www.facebook.com/HhomeMart/" data-layout="button" data-action="like" data-size="large" data-show-faces="true" data-share="true"></div></td>
  </tr>
</table>
    </div>
    
    
    <hr color=grey SIZE=1/>
    <div id="admin"></div>
<script type="text/javascript">
if(access=='admin'){ document.getElementById('admin').innerHTML='<div style="width:100%; background-color:red; color:white; font-size:18px"><center>ADMIN ACCESS ENABLED</center></div> ';}
</script>    
    
    <div id="container">
	<script type="text/javascript">
	for(var k=0;k<json.length;k++)
	{
		if(access!='admin'){
		
    $("#container").append('<div class="product"><div style=" border-style:solid; border-color:#CCC; border-width:1px; padding:5px; margin-bottom:10px;"><img src="'+json[k].image+'" height="250" width="188"></div><caption><strong>'+json[k].productname+'</strong></caption></img><p>'+json[k].description+'</p><span style="width:200px; text-align:right;">$'+json[k].cost+'</span><button class="cartbutton" onClick="store('+json[k].prodid+',\''+json[k].productname+'\')">Add to Cart</button></div>');
		}//ad
		else{
			   $("#container").append('<div class="product"><div style=" border-style:solid; border-color:#CCC; border-width:1px; padding:5px; margin-bottom:10px;"><img src="'+json[k].image+'" height="250" width="188"></div><caption><strong>'+json[k].productname+'</strong></caption></img><p>'+json[k].description+'</p><span style="width:200px; text-align:right;">$'+json[k].cost+'</span><button class="cartbutton" onClick="store('+json[k].prodid+',\''+json[k].productname+'\')">Add to Cart</button><br /><button class="deletebutton" onClick="deleteit('+json[k].prodid+',\''+json[k].productname+'\')">Delete</button></div>');
			}
    }
	
	function store(id,name){
		$.ajaxSetup({
   headers: { 'X-CSRF-Token' : $('meta[name=_token]').attr('content') }
});
 

		 $.get("../addtocart/"+id+"/"+cid, function(data) {
			console.log(data);
			
	if(data == 'added')
	{
		alert(name+' added to cart');
		cartitem=cartitem+1;
		 document.getElementById('cid').innerHTML='<a href="../getcart/'+c+'">CART ('+cartitem+')</a>';
		}else{
			alert('Try Again');
			//add redirect here
			}
				
         });	
		
		}
		
		
		
function deleteit(id,name){
	
	 $.get("../deletelisting/"+id, function(data) {
			console.log(data);
			
	if(data == 'deleted')
	{
		alert(name+' removed from cart');
		location.reload();

		}else{
			alert('Try Again');
			//add redirect here
			}
				
         });	
	
	
	
	alert(name+id);
	}		
    </script>
    
    
    
   
</body>
</html>