<script type="text/javascript">
var json=<?php echo $arihant?>;
console.log(json);
</script>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Colonialist | George Washington University</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0" />
    
	<link rel="stylesheet" type="text/css" href="http://www.webcase.in/lab/css/reset.css">
	<link rel="stylesheet" type="text/css" href="http://www.webcase.in/lab/css/main_responsive.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="http://www.webcase.in/lab/js/jquery.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script type="text/javascript" src="http://www.webcase.in/lab/js/main.js"></script>

  <style>
table th,td {
	margin: 10px;
	padding:10px;
	 border:thin solid #CCC;
	vertical-align: middle;
	height:50px;	 
		}	
a{
	color:red;}
eandp{
	
	color:black;}
.eandp a{
	color:blue;}	
    </style>
            
        </head>
        <body>
        <div id="newbody"></div>
        
        <script type="text/javascript">
       function showUpdate(id){
		   //var url='<iframe src="edit/'+id;
		   
            //$( "#body" ).html(url+'" height="1000px" width="100%"/>');
			var url="/laravel/edit/"+id;
			location.replace(url);
			
document.getElementById('post').style.display='none';
document.getElementById('showall').style.display='none';

            }
			
 
        </script>
        
        <div id="body">
        
	<header>
		<div class="wrapper">
			<img src="http://www.webcase.in/lab/img/logo.png" alt="GWU" class="logo" height="60">
			<a href="#" class="menu_icon" id="menu_icon"></a>
			<nav id="nav_menu">
				<ul>
					<li><a href="index.html">Home</a></li>
					<li><a href="post.html">Post a Classified</a></li>
					<li><a href="view.php">View Products</a></li>
					<li><a href="#">Contact</a></li>
				</ul>
			</nav>

			<ul class="social">
				<li><a class="fb" href="https://www.facebook.com/georgewashingtonuniversity"></a></li>
				<li><a class="twitter" href="https://twitter.com/GWtweets"></a></li>
			</ul>
	  </div>
	</header><!--  End Header  -->

	<section class="billboard">
			<div class="wrapper">
				<div class="caption">
					<p>George Washington University</p>
					<p>Colonialist</p>
                    <p>Classified Ads for Colonials</p>
				</div>
			</div>
	</section>
    <br>
    <center><button id="showPost" style="height:40px; color:blue">Post A Classified </button></center>
    <script type="text/javascript">
    	$("#showPost").click(function(){
			
				document.getElementById('post').style.display='inherit';
document.getElementById('showall').style.display='none';
				
				});
    </script>
    
    
	<section id="showall" class="cta">
		<h3>All Listings<br>
		  <br>
		</h3>
	  <table width="100%" border="2" align="center" cellpadding="10" cellspacing="5" id="finaltable">
		  <tr bordercolor="#000000">
		    <th width="11%" scope="col">Image</th>
		    <th width="14%" scope="col">Product or Service Name</th>
		    <th width="10%" scope="col">Category</th>
		    <th width="11%" scope="col">Name</th>
		    <th width="16%" scope="col">Email and Phone</th>
		    <th width="11%" scope="col">Date Posted</th>
		    <th width="18%" scope="col">Description</th>
		    <th width="9%" scope="col">Cost</th>
	      </tr>
         <script type="text/javascript"> 
        
		function createView(){
		
			//var json=JSON.parse(data);
			console.log(json);
			for(var k=0;k<json.length;k++)
		$("#finaltable").append('<tr><td><a href=\"uploaded_files/'+json[k].pic+'\"><img src=\"uploaded_files/'+json[k].pic+'\"></a></td><td>'+json[k].product+'<br><span style=\"color:red; \"> <a onClick=\"showUpdate('+json[k].id+')\">Edit</a>  |  <a onclick=\'deleteThis('+json[k].id+')\'>Delete</span></a></td><td valign=\"middle\">'+json[k].category+'</td><td>"'+json[k].name+'"</td><td><span class=\"eandp\"><a href=\"mailto:'+json[k].email+'\">'+json[k].email+'</a><br><a href=\"tel:+1'+json[k].phone+'\>'+json[k].phone+'"</a></span></td><td>'+json[k].date+'</td><td>'+json[k].description+'</td><td>$'+json[k].cost+'</td></tr></span>');

			
			
		}
			
			createView();
			
function deleteThis(did){
	console.log(did);
	$.get("delete/"+did,{g:'deleteit',id:did},function(data){
		console.log(data);
		if(data=='deleted'){
			alert('Entry with id '+did+' deleted');
			location.replace("/laravel/showall");
			
			}
	});
				

	//createView();
	
	
	}		
	
	
  				
		 </script>
	  </table>
      <div id="try"></div>
      
      <div id="result"></div>
            
    </section>



<section id="edit"></section>



<section id="post" style="display:none">
<section class="cta">
		<h3>Post a classified</h3>
		<p>* fields are required</p>
         <div class="form"><form id="myForm" name="myForm" action="form_process.php" onsubmit="return validate()" method="post" enctype="multipart/form-data">
        
           <p>Product or Service Name*<br />
            <input id="fname" type="text" name="fname" class="inputField" placeholder="Product or Service Name"/>
           </p>
           <p>          Name* <br>
              
            <input type="text" name="pname" id="pname" class="inputField" placeholder="Enter your name" />
          </p>
           <p>Email*<br>
              
            <input id="email" type="text" name="email" class="inputField" placeholder="example@domain.com" />
           </p>
           <p>
            Phone*<br>
            <input type="number" id="phone" name="phone" class="inputField" placeholder="9876543210" />
           </p>
           <p>Cost*<br>
             <label for="price"></label>
             <input name="price" type="number" class="inputField" id="price" placeholder="Enter numeric cost">
           </p>
           <p>Description*<br>
             <label for="description"></label>
             <textarea name="description2" class="inputField" id="description" placeholder="Add description"></textarea>
           </p>
           <p>Category*<br>
             <label for="category"></label>
             <select name="category" class="inputField" id="category" style="width:200px">
               <option value="apartments">Apartments</option>
               <option value="electronics">Electronics</option>
               <option value="oncampusjobs">On-Campus Jobs</option>
               <option value="furniture">Furniture</option>
               <option value="books">Books</option>
               <option value="carpool">Carpool</option>
               <option value="parking">Parking</option>
               <option value="tickets">Tickets</option>
               <option value="others">Others</option>
             </select>
           </p>
           <p> Date*<br>
<input type="date" id="date22" name="date22" class="inputField" style="width:200px"/></p>
           <p>Image:</p>
             <input type="file" name="pic" accept="image/*" />
             <br/>
             <!--<input   type="submit" class=" button" value="Submit" />-->
             <button type="button" id="submit" value="Submit">Submit</button>
             <br>
           </p>
         </form>
        </div>  
	</section>
    <div id="resultpost" style=" width:400px; margin-left:auto; margin-right:auto"></div>
    <div id="newview"></div>
    <script type="text/javascript">
    $("#submit").click(function(){
		$.ajaxSetup({
   headers: { 'X-CSRF-Token' : $('meta[name=_token]').attr('content') }
});





 /*   $.ajax({
        url: "create",
        type:"POST",
		contentType: "json",
    processData: false,
        beforeSend: function (xhr) {
            var token = $('meta[name="csrf_token"]').attr('content');

            if (token) {
                  return xhr.setRequestHeader('X-CSRF-TOKEN', token);
            }
        },
        data: { testdata : 'testdatacontent' },
        success:function(data){
            alert(data);
        },error:function(){ 
            alert("error!!!!");
        }
    }); //end of ajax



*/










		 $.post("create", $("#myForm").serialize(), function(data) {
         document.getElementById('result').innerHTML='';
		var json1=JSON.parse(data);
			console.log(json);
			for(var k=0;k<json.length;k++){
				$("#resultpost").append(json1[k]+'<br/> <br/>');
				}
				document.getElementById('finaltable').innerHTML='<table width="100%" border="2" align="center" cellpadding="10" cellspacing="5" id="finaltable"><tr bordercolor="#000000"><th width="11%" scope="col">Image</th><th width="14%" scope="col">Product or Service Name</th><th width="10%" scope="col">Category</th><th width="11%" scope="col">Name</th><th width="16%" scope="col">Email and Phone</th><th width="11%" scope="col">Date Posted</th><th width="18%" scope="col">Description</th><th width="9%" scope="col">Cost</th></tr>';
				
				
				createView();
				location.replace("/laravel/showall");
				//document.getElementById('showall').style.display='inherit';
				//document.getElementById('finaltable').style.display='none';
				//document.getElementById('post').style.display='none';
				
         });	
		});
    
    
    </script>
 
</section>









	<footer>
		<img src="http://www.webcase.in/lab/img/logo.png" alt="GWU Colonialist">
		<p class="rights">Copyright © Colonialist - <a href="http://www.webcase.in">Developed by Arihant Jain - Other Projects by me (WebCase)</a></p>
	</footer><!--  End Footer  -->
    </div>
</body>
</html>