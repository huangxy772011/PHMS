<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/js-cookie/2.1.3/js.cookie.min.js"></script>

<title>Contact | HomeMart</title>
<script type="text/javascript">
</script>
 <link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
  <script
  src="https://code.jquery.com/jquery-3.1.1.min.js"
  integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  crossorigin="anonymous"></script>
  <style>
  .cart{
	  margin-right:
	  auto;
	  margin-left:auto;
	  padding:10px;
	  border-style:solid;
	  border-width:1px;
	  border-color:#CCC;
	  margin-bottom:10px}
	  .cartbutton{
		  padding:10px;
		width:100%;
		height:50px;
		text-align:center;
		color:white;
		background-color:green;
		border:none;
		font-size:16px;
		}
		a:link {
    text-decoration: none;
	color:#09F;
}

a:visited {
    text-decoration: none;
	color:#09F;
}

a:hover {
    text-decoration: underline;
}

a:active {
    text-decoration: underline;
}
body{
	font-family:Tahoma, Geneva, sans-serif;
	}

  </style>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/js-cookie/2.1.3/js.cookie.min.js"></script>
<script type="text/javascript">
var c=Cookies.get('id');</script>
</head>

<body>
<h1 align="center" style="font-family: 'Lobster', cursive;"><span style="color:#06F">Home</span><span style="color:#0C3">Mart</span></h1>
    <center>Local produce, Delivered.</center>
	<hr color=grey SIZE=1/>
<div id="nav"><table width="100%" border="0" cellspacing="1" cellpadding="1">
  <tr>
    <td><a href="/laravel/home">HOME</a></td>
    <td id="p"><script type="text/javascript">
    document.getElementById('p').innerHTML='<a href="/laravel/getproducts/'+c+'">PRODUCTS</a>';
    </script></td>
    <td id="cid"><script type="text/javascript">
    document.getElementById('cid').innerHTML='<a href="/laravel/getcart/'+c+'">CART</a>';
    </script></td>
    <td><a href="/laravel/contact">CONTACT</a></td>
    <td><div id="update"><script type="text/javascript"> document.getElementById('update').innerHTML='<a href="/laravel/edit/'+c+'">UPDATE PROFILE</a>';</script></td>
    <td><div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.8&appId=370203893082428";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div class="fb-like" data-href="https://www.facebook.com/HhomeMart/" data-layout="button" data-action="like" data-size="large" data-show-faces="true" data-share="true"></div></td>
  </tr>
</table>
    </div>
    <hr color=grey SIZE=1/>
   <div id="cart"></div>
   
   <div class="cart" style="width:800px">
   <center>
   <h1>Contact US</h1>
   <h2 style="color:blue">Message us on Facebook</h2>
    <script>

    window.fbAsyncInit = function() {
      FB.init({
        appId: "1795848020690216",
        xfbml: true,
        version: "v2.6"
      });

    };

    (function(d, s, id){
       var js, fjs = d.getElementsByTagName(s)[0];
       if (d.getElementById(id)) { return; }
       js = d.createElement(s); js.id = id;
       js.src = "//connect.facebook.net/en_US/sdk.js";
       fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));

  </script>


<div class="fb-messengermessageus" 
  messenger_app_id="1795848020690216" 
  page_id="1098861716899698"
  color="blue"
  size="large" >
</div>
   </center>
   </div>
</body>
</html>