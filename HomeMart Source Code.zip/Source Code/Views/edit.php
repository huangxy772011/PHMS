<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Colonialist | George Washington University</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0" />
	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/main_responsive.css">
    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/main.js"></script>
    <style>
    </style>
    
</head>
<body>

	<header>
		<div class="wrapper">
			<img src="img/logo.png" alt="GWU" class="logo" height="60">
			<a href="#" class="menu_icon" id="menu_icon"></a>
			<nav id="nav_menu">
				<ul>
					<li><a href="index.html">Home</a></li>
					<li><a href="post.html">Post a Classified</a></li>
					<li><a href="view.php">View Products</a></li>
					<li><a href="#">Contact</a></li>
				</ul>
			</nav>

			<ul class="social">
				<li><a class="fb" href="https://www.facebook.com/georgewashingtonuniversity"></a></li>
				<li><a class="twitter" href="https://twitter.com/GWtweets"></a></li>
			</ul>
	  </div>
	</header><!--  End Header  -->

	<section class="billboard">
			<div class="wrapper">
				<div class="caption">
					<p>George Washington University</p>
					<p>Colonialist</p>
                    <p>Classified Ads for Colonials</p>
				</div>
			</div>
	</section>
<section class="cta">
		<h3>Post a classified</h3>
		<p>* fields are required</p>
        
        
        <?php include '/display_inform.php';?>
        
        <script type="text/javascript">
        // pass PHP variable declared in above file to JavaScript variable
        var json = <?php echo $json_object ?>
        </script>

         <div class="form"><form name="myForm" id="myForm" action="updated.php?id=<?php echo $id; ?>" onsubmit="return validate()" method="post" enctype="multipart/form-data">
        
           <p>Product or Service Name*<br />
           <script type="text/javascript">
            document.write('<input id="pname" type="text" name="pname" class="inputField" placeholder="Product or Service Name" value="' + json.listing.product + '"/></p>');
		   </script>
           <p>          Name* <br>
          <script type="text/javascript">     
           document.write('<input id="fname" type="text" name="fname" class="inputField" placeholder="Enter Name" value="' + json.listing.name + '"/></p>');</script>
           <p>Email*<br>
            <script type="text/javascript">   
          document.write('<input id="email" type="email" name="email" class="inputField" placeholder="example@abcd.com" value="' + json.listing.email + '"/></p>');</script>
           <p>
            Phone*<br>
			 <script type="text/javascript">
           document.write('<input id="phone" type="number" name="phone" class="inputField" placeholder="9876543210" value="' + json.listing.phone + '"/></p>');</script>
           <p>Cost*<br>
		    <script type="text/javascript">
            document.write('<input id="price" type="number" name="price" class="inputField" placeholder="Enter Numeric Cost" value="' + json.listing.cost + '"/></p>');</script>
           <p>Description*<br>
		   
             <label for="description"></label>
			  <script type="text/javascript">
             document.write('<textarea name="description2" class="inputField" id="description" placeholder="Add description">'+json.listing.description+'</textarea></p>');
		   </script>
           <p>Category*<br>
             <label for="category"></label>
             <select name="category" class="inputField" id="category" style="width:200px" value="<?php echo $category;?>">
             
               <option value="apartments" <?php if ($category=="apartments"){echo 'selected="selected"';}  ?>>Apartments</option>
               <option value="electronics" <?php if ($category=="electronics"){echo 'selected="selected"';}  ?>>Electronics</option>
               <option value="oncampusjobs" <?php if ($category=="oncampusjobs"){echo 'selected="selected"';}  ?>>On-Campus Jobs</option>
               <option value="furniture" <?php if ($category=="furniture"){echo 'selected="selected"';}  ?>>Furniture</option>
               <option value="books" <?php if ($category=="books"){echo 'selected="selected"';}  ?>>Books</option>
               <option value="carpool" <?php if ($category=="carpool"){echo 'selected="selected"';}  ?>>Carpool</option>
               <option value="parking" <?php if ($category=="parking"){echo 'selected="selected"';}  ?>>Parking</option>
               <option value="tickets" <?php if ($category=="tickets"){echo 'selected="selected"';}  ?>>Tickets</option>
               <option value="others" <?php if ($category=="others"){echo 'selected="selected"';}  ?>>Others</option>
             </select>
           </p>
           <p> Date*<br>
           <script type="text/javascript">
document.write('<input type="date" id="date22" name="date22" class="inputField" style="width:200px" value="'+json.listing.date+'"/></p>');
</script>
           <p>Image:</p>
             <script type="text/javascript">
             document.write('<input type="file" name="pic" accept="image/*" value="'+json.listing.pic+'" />');
             </script>
			 <br/>
             <button   type="button" class=" button" id="submit" value="Submit"> SUBMIT </button>
             <br>
           </p>
         </form>
        </div>
    <div id="result"></div>
    
 <script type="text/javascript">   
    
   $("#submit").click(function(){
		 $.post("index.php?g=update&id="+json.listing.id, $("#myForm").serialize(), function(data) {
         document.getElementById('result').innerHTML='';
		var json=JSON.parse(data);
			console.log(data);
			for(var k=0;k<json.length;k++){
				$("#result").append(json[k]+'<br/> <br/>');
				}
         });	
		});  
    
    alert("Your Continued Session ID is: <?php echo $_SESSION['uid']; ?>");   
 
 </script>   
	</section>

	<footer>
		<img src="img/logo.png" alt="GWU Colonialist">
		<p class="rights">Copyright © Colonialist - <a href="http://www.webcase.in">Developed by Arihant Jain - Other Projects by me (WebCase)</a></p>
	</footer><!--  End Footer  -->




</body>
</html>