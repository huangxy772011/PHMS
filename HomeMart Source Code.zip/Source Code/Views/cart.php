<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/js-cookie/2.1.3/js.cookie.min.js"></script>
<title>Cart | HomeMart</title>
<script type="text/javascript">
var json=<?php echo $cart?>;
var custid=<?php echo $custid?>;

console.log(json);
</script>
 <link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
  <script
  src="https://code.jquery.com/jquery-3.1.1.min.js"
  integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  crossorigin="anonymous"></script>
  <style>
  .remove{
	 border:none;
	 color:white;
	 background-color:#F36; 
	  
	  }
  .cart{
	  margin-right:
	  auto;
	  margin-left:auto;
	  padding:10px;
	  border-style:solid;
	  border-width:1px;
	  border-color:#CCC;
	  margin-bottom:10px}
	  .cartbutton{
		  padding:10px;
		width:100%;
		height:50px;
		text-align:center;
		color:white;
		background-color:green;
		border:none;
		font-size:16px;
		}
		body{
	font-family:Tahoma, Geneva, sans-serif;
	}
	
a:link {
    text-decoration: none;
	color:#09F;
}

a:visited {
    text-decoration: none;
	color:#09F;
}

a:hover {
    text-decoration: underline;
}

a:active {
    text-decoration: underline;
}
body{
	font-family:Tahoma, Geneva, sans-serif;
	}
		
  </style>
  <script type="text/javascript">
  var c=Cookies.get('id');
  </script>
</head>

<body>
<h1 align="center" style="font-family: 'Lobster', cursive;"><span style="color:#06F">Home</span><span style="color:#0C3">Mart</span></h1>
    <center>Local produce, Delivered.</center>
	<hr color=grey SIZE=1/>
     <div id="nav"><table width="100%" border="0" cellspacing="1" cellpadding="1">
  <tr>
    <td><a href="/laravel/home">HOME</a></td>
    <td id="p"><script type="text/javascript">
    document.getElementById('p').innerHTML='<a href="../getproducts/'+c+'">PRODUCTS</a>';
    </script></td>
    <td id="cid"><script type="text/javascript">
    document.getElementById('cid').innerHTML='<a href="../getcart/'+c+'">CART</a>';
    </script></td>
    <td><a href="/laravel/contact">CONTACT</a></td>
    <td><div id="update"><script type="text/javascript"> document.getElementById('update').innerHTML='<a href="../edit/'+c+'">UPDATE PROFILE</a>';</script></td>
    <td><div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.8&appId=370203893082428";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div class="fb-like" data-href="https://www.facebook.com/HhomeMart/" data-layout="button" data-action="like" data-size="large" data-show-faces="true" data-share="true"></div></td>
  </tr>
</table>
    </div>
    <hr color=grey SIZE=1/>
   <center> <h3> Your Cart</h3> </center>
   

   <div id="cart"></div>
   <script type="text/javascript">
   var total=0;
   for(var a=0;a<json.length;a++){
	   $("#cart").append('<table width="60%" border="0"  class="cart"><tr><td  style="width:100px; "><img src="'+json[a][0].image+'" height="200px" width="200px" style="margin-right:10px"/> </td><td><h3>'+json[a][0].productname+'</h3><h3><span style="color:#06F">$'+json[a][0].cost+'</span></h3><button class="remove"  style="float:right;" onClick="deletecart('+json[a][0].prodid+','+custid+')">Remove</button></td></tr></table>');
	   total=total+parseFloat(json[a][0].cost);
	   }
   </script>
   
   <div class="cart" style="width:200px">
   <center>
   <h3 style="color:red">Your Total <div id="total"></div><script type="text/javascript"> $("#total").append('$'+total+'<br><br><button id="order" onClick="place()" class="cartbutton">Place Order</button>');
   
   function deletecart(id,cid){
	   $.get("../deletecart/"+id+"/"+cid, function(data) {
			console.log(data);
			
	if(data == 'deleted')
	{
		alert('Product Removed from Cart');
		location.reload();

		}else{
			alert('Try Again');
			//add redirect here
			}
				
         });	
	   }
   
   function place(){
	   window.location='../placed';
	   }
   </script> 
   </center>
   </div>
</body>
</html>