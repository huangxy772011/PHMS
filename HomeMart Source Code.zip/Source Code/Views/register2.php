<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
     <link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">

	<meta charset="utf-8" />
	<title>Update Profile | HomeMart</title>
    <script
  src="https://code.jquery.com/jquery-3.1.1.min.js"
  integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  crossorigin="anonymous"></script>
	<style type="text/css">
		.divBackGro{
			 width:90%; 
			 height:800px; 
			 border:solid 1px #eee;
			 margin: 10px auto;
			 background-image:url(http://www.webcase.in/homemart/homebg.jpg);
			 background-repeat: no-repeat; 
		     background-positon: 100%, 100%; 
		}
		.whiteGro{
			 width:50%; 
			 height:400px; 
			 border:solid 0px #eee;
			 margin: 80px auto;
			 background-image:url(http://www.webcase.in/homemart/1.png);
			 background-repeat: no-repeat; 
		     background-positon: 100%, 100%; 
		}body{
	font-family:Tahoma, Geneva, sans-serif;
	}
		
	</style>
  </head>
  <body> 
  <script type="text/javascript">
  var populate=<?php echo $homemart?>;
  console.log(populate);  
  </script>
		<h1 align="center" style="font-family: 'Lobster', cursive;"><span style="color:#06F">Home</span><span style="color:#0C3">Mart</span></h1>
    <center>Local produce, Delivered.</center>
	<hr color=grey SIZE=1/>
	<div class="divBackGro">
		<div class="whiteGro">
			<br><br><form id="myForm">
			<table align="center"  style = "color:#eee;font-size:15pt;">
				<tr >
					<td align="center" height="40px">First name</td>
					<td align="center" height="30px"><script type="text/javascript">
					document.write('<input type="text" name="firstname" id="firstname" style="width:300px; height:30px" value="'+populate[0].firstname+'" ></input>');</script></td>
				</tr>
				<tr>
					<td align="center" height="40px">Last name</td>
					<td align="center" height="30px"><script type="text/javascript">
					document.write('<input type="text" name="lastname" id="lastname" style="width:300px; height:30px" value="'+populate[0].lastname+'" ></input>');</script></td>
				</tr>
				<tr>
					<td align="center" height="40px">Address</td>
					<td align="center" height="30px"><script type="text/javascript">
					document.write('<input type="text" name="address" id="address" style="width:300px; height:30px" value="'+populate[0].address+'" ></input>');</script></td>
				</tr>
				<tr>
					<td align="center" height="40px">Email</td>
					<td align="center" height="30px"><script type="text/javascript">
					document.write('<input type="email" name="email" id="email" style="width:300px; height:30px" value="'+populate[0].email+'" ></input>');</script></td>
				</tr>
				<tr>
					<td align="center" height="40px">Phone</td>
					<td align="center" height="30px"><script type="text/javascript">
					document.write('<input type="text" name="phone" id="phone" style="width:300px; height:30px" value="'+populate[0].phone+'" ></input>');</script></td>
				</tr>
				<tr>
					<td align="center" height="40px">Password</td>
					<td align="center" height="30px"><input type="password" name="password"  id="password" style="width:300px; height:30px"></input></td>
				</tr>
				<tr>
					<td colspan="2" align="center" height="60px"><input id="submit" type="button" value="UPDATE" style="color:#eee;width:100px; height:40px; border:0;background-color: #0C3"" /></td>
				</tr>
			</table>
            </form>
            
              <script type="text/javascript">
                     $("#submit").click(function(){
		$.ajaxSetup({
   headers: { 'X-CSRF-Token' : $('meta[name=_token]').attr('content') }
});
 

		 $.post("../register/"+populate[0].id, $("#myForm").serialize(), function(data) {
		var json1=JSON.parse(data);
			console.log(json1);
			
	if(json1 == undefined)
	{
		alert('Authentication Failed. Please try again');
		}else{
			alert('Profile Updated Successfully');
			window.location='../getproducts/'+json1.id;
			}
				
         });	
		});
    </script>
            
            
            
		</div>
	</div>
	<div>
		<h5 align="center">Copyright © 2016 HomeMart</h5>
	</div>
  </body>
</html>