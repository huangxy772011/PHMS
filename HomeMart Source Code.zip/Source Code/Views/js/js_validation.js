//Calling the validate function when user submits form
	window.load = function() {
	  var myForm = document.getElementById('myForm');
	  myForm.onsubmit = function(e) {
		  return validate();
	  }  
	}
	
//Validation funtion
	function validate() {
	
		var product_name = document.forms["myForm"]["fname"].value;
		var name = document.forms["myForm"]["pname"].value;
		var email = document.forms["myForm"]["email"].value;
		var phone = document.forms["myForm"]["phone"].value;
		var price = document.forms["myForm"]["price"].value;
		var date22 = document.forms["myForm"]["date22"].value;
		var description = document.forms["myForm"]["description"].value;
		
		var d = new Date();
		var values=date22.split("-");
		makeWhite();
			
		if (product_name==null || product_name == "" ) {
			makeRed('fname');
			alert("Enter Product Name");
			return false;}
		else if (name == null || name == ""|| isNaN(name) == false) {
			makeRed('pname');
			alert("Enter valid name");
			return false;		
		}
		else if(email == '' || email.indexOf('@') == -1 || email.indexOf('.') == -1) 
		{
			makeRed('email');
			alert("Insert valid Email Address");
			return false;	
			}
		else if(phone == ''|| phone <1000000000 || phone >9999999999){
			makeRed('phone');
			alert("Enter valid phone number");
			return false;	
			
			}
			else if(price == ''|| price <0 || price >9999999999){
			makeRed('price');
			alert("Enter valid cost");
			return false;	
			
			}
			else if(description == ''|| description == null){
			makeRed('description');
			alert("Enter a description");
			return false;	
			
			}
			
			else if(values[0]=="" || values[0]==null||values[0]>d.getFullYear() || values[1]> 1+d.getMonth() || values[2]>d.getDate()){
			makeRed('date22');
			alert("Please Check Date");
		return false;
		}	
}
	
//Function to make invalid input fields red 
function makeRed(inputDiv){
	var div= document.getElementById(inputDiv);
	div.style.backgroundColor="#FFA07A";
    div.style.border = "2px solid #FF0000	";
    return false;
}

//Function to clear fields when input is valid
function makeWhite(){
	var divList = document.querySelectorAll(".inputField");
	for (var i=0;i<divList.length;i++){
    divList[i].style.backgroundColor="#FFFFFF";
    divList[i].style.border = "1px solid #BDBDBD";
    }
 return false;
}