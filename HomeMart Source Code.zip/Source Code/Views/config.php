<?php
error_reporting(E_ALL);

$host="localhost";
$username="root";
$password="";
$databse="mydb";

if($connect=mysqli_connect($host,$username,$password,$databse)){
	//echo 'connected';
	}
	else {
		echo mysqli_error($connect);
		}
		

?>