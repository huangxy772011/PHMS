<!DOCTYPE html>
<html>
<head lang="en">
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   
   <meta name="description" content="">
   <meta name="author" content="">
   <link rel="icon" href="../../favicon.ico">
   <title>Existing Record</title>
   <link href="bootstrap-3.3.5/docs/dist/css/bootstrap.min.css" rel="stylesheet">
   <link href="bootstrap-3.3.5/docs/examples/jumbotron/jumbotron.css" rel="stylesheet">
   
   <script src="bootstrap-3.3.5/docs/assets/js/ie-emulation-modes-warning.js"></script>
   
   <link rel="stylesheet" href="leftAlign.css" />
   <link rel="stylesheet" href="PHMS.css" />
   <link href='http://fonts.googleapis.com/css?family=Lobster'
rel='stylesheet' type='text/css'>
   <link href='http://fonts.googleapis.com/css?family=Lato'
rel='stylesheet' type='text/css'>
   <style>

   </style>
</head>
<body>
	<nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="homepage.html">Pet Hospital Management System</a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li><a href="homepage.html">Home</a></li>
            <li role="presentation" class="dropdown active">
				<a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
					Record <span class="caret"></span>
				</a>
				<ul class="changeDropDown dropdown-menu">
				<a class="dropDown" href="newrecord.php">New Record</a><br/><br/>
				<a class="dropDown" href="existing.php">Update Record</a>
				</ul></li>
            <li><a href="manageinfo.php">Show Record</a></li>
			<li><a href="deleteReco.php">Delete Record</a></li>
			
			
			
			
          </ul>
        </div><!--/.nav-collapse -->
      </div>
	 </nav>

	 <div class="container">
      <!-- Example row of columns -->
      <div class="row">
		
		<div class="col-md-10">
		
		<fieldset>
			<legend>Updating Patient Record </legend>
			<?php include 'retrieve.php';?>	
	  <hr>
	   <div class="figure">
		<figure>
			<a href="#top"> <img src="back-to-top.png" alt="back to top" title="Top" width="50" height="50" />  </a>
		</figure>
	  </div>
	   <footer>
	    <p><a href="homepage.html">Home</a> | <a href="#">About</a> | <a href="#">Contact us</a> | <a href="#">Search</a></p>
        <p><em>Copyright &copy;  Company 2014</em></p>
      </footer>
	 </div>

<!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="bootstrap-3.3.5/docs/dist/js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="bootstrap-3.3.5/docs/assets/js/ie10-viewport-bug-workaround.js"></script>
</body>
</html>