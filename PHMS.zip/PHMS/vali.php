<?php
error_reporting(E_ALL);

ini_set('display_errors', 1);

$servername = "localhost";
$username = "root";
$password = "ycx2l0aYXLxH";
$dbname = "recordDB";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
}

$nameErr = $emailErr = $phoneErr = $speciesErr = $genderErr = $websiteErr = $fileToUploadErr = $petnameErr = $neuterErr = $ageErr = $dateErr = "";
$name = $email = $phone = $species = $gender = $comment = $website = $fileToUpload = $petname = $neuter = $date = $age = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   if (empty($_POST["name"])) {
     $nameErr = "Owner name is required";
   } 
   else {
	 $name = test_input($_POST["name"]);
     if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
       $nameErr = "Please enter only letters"; 
     }
   }
   
   if (empty($_POST["email"])) {
     $emailErr = "Email is required";
   } else {
     $email = test_input($_POST["email"]);
     if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
       $emailErr = "Invalid email address"; 
     }
   }
   
   if (empty($_POST["phone"])) {
     $phoneErr = "Phone number is required";
   } else {
     $phone = test_input($_POST["phone"]);
     if (!preg_match("/^[0-9]{10}$/", $phone)) {
       $phoneErr = "Invalid phone number"; 
     }
   }
   
   if(isset($_REQUEST["species"]) && $_REQUEST["species"] == "") { 
     $speciesErr = "Please select a species";
	 } 
	 else {
     $species = test_input($_POST["species"]);
   } 
   
   
	  

   if (empty($_POST["gender"])) {
     $genderErr = "Gender is required";
   } else {
     $gender = $_POST["gender"];
   }
   
   if (empty($_POST["petname"])) {
     $petnameErr = "Pet name is required";
   } else {
     $petname = test_input($_POST["petname"]);
     // check if name only contains letters and whitespace
     if (!preg_match("/^[a-zA-Z ]*$/",$petname)) {
       $petnameErr = "Please enter only letters"; 
     }
   }
   if (empty($_POST["neuter"])) {
     $neuterErr = "Neuter info is required";
   } else {
     $neuter = test_input($_POST["neuter"]);
   }
   
  if  (empty($_POST["date"])) {
		$dateErr="";
  }
  elseif (!preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/",$_POST["date"])) {
       $dateErr = "Invalid date formate, only YYYY-MM-DD is accepted"; 
  }
  else{
		$date = test_input($_POST["date"]); 
   }
  
 
  if (!preg_match('/^[0-9]*(\.[0-9]+)?$/',$_POST["age"])) {
       $ageErr = "Invalid age formate, only integer and float are accepted"; 
     }
     else{
		$age = test_input($_POST["age"]); 
	 }
		 

	
$desc = $_POST["desc"];

#if ($nameErr=="" || $emailErr == "" || $phoneErr =="" || $speciesErr =="" || $genderErr =="" || $fileToUploadErr =="" || #$petnameErr =="" || $neuterErr =="" || $weightErr=="" ){
#	return;
#}
if ($nameErr!="" || $emailErr != "" || $phoneErr !="" || $speciesErr !="" || $genderErr !="" || $petnameErr !="" || $neuterErr != "" || $ageErr != "" || $dateErr != "" ){
	return;
}


$sql = "INSERT INTO patient (Ownername, Owneremail, Ownerphone, Species, Petname, Gender, Neutered, Age, Visitdate, Description) VALUES ('$name', '$email', '$phone', '$species', '$petname', '$gender', '$neuter', '$age', '$date', '$desc')";	





if (mysqli_query($conn, $sql)) {
   
	echo '<script language="javascript">';
    echo 'alert("New record created successfully")';
    echo '</script>';
} else {
    echo "  " . $sql . "<br>" . mysqli_error($conn);
}
/*
$returnsql = "SELECT * FROM p_info";
if (mysqli_query($conn, $returnsql)) {
	$result = mysql_query($returnsql);
	echo '<table>';
	while ($row = mysql_fetch_array($result)){
		echo '<tr>';
		foreach ($row as $field){
			echo '<td>' . htmlspecialchars($field) . '</td>';
		}
		echo '</tr>';
	}
	echo '</table>';
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
*/



mysqli_close($conn);

}
/*if ($_SERVER["REQUEST_METHOD"] == "GET") {
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	// Check connection
	if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
	}
	
	$returnsql = "SELECT * FROM p_info";
		$result = mysqli_query($returnsql);
		echo '<table>';
		while ($row = mysqli_fetch_array($result)){
			echo '<tr>';
			foreach ($row as $field){
				echo '<td>' . htmlspecialchars($field) . '</td>';
			}
			echo '</tr>';
		}
		echo '</table>';
	mysqli_close($conn);
	

}
*/
function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}


 ?> 
 
