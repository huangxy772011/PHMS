<?php

$servername = "localhost";
$username = "root";
$password = "ycx2l0aYXLxH";
$dbname = "recordDB";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
}
?>

<?php


$sql = "select Ownername, Owneremail, Ownerphone, Species, Petname, Gender, Neutered, Age, Visitdate, Description from patient";
$result = $conn->query($sql);
echo "<h2>Patient Information</h2>";
echo "<table>";
echo "<tr>";
echo "<th>Owner name</th>";
echo "<th>Owner email</th>";
echo "<th>Owner phone</th>";

echo "<th>Species </th>";
echo "<th>Pet name</th>";

echo "<th>Gender</th>";
echo "<th>Neutered</th>";

echo "<th>Age</th>";
echo "<th>Visit date </th>";
echo "<th>Description</th>";
echo "</tr>";
if ($result->num_rows > 0) {
	while ($row = $result->fetch_assoc()) {
		echo "<tr>";
		echo "<td>";
		echo $row["Ownername"];
		echo "</td>";
		echo "<td>";
		echo $row["Owneremail"];
		echo "</td>";
		echo "<td>";
		echo $row["Ownerphone"];
		echo "</td>";
		
		echo "<td>";
		echo $row["Species"];
		echo "</td>";
		echo "<td>";
		echo $row["Petname"];
		echo "</td>";
		
		echo "<td>";
		echo $row["Gender"];
		echo "</td>";
		echo "<td>";
		echo $row["Neutered"];
		echo "</td>";
		
		echo "<td>";
		echo $row["Age"];
		echo "</td>";
		echo "<td>";
		echo $row["Visitdate"];
		echo "</td>";
		echo "<td>";
		echo $row["Description"];
		echo "</td>";
		echo "</tr>";
	}
	echo "</table>";
	echo "<br/><br/>";
	echo "<a href='homepage.html'>Back to Homepage</a></br>";
		echo "<a href='newrecord.php'>Add Records</a></br>";
			echo "<a href='existing.php'>Update Records</a></br>";
				echo "<a href='deleteReco.php'>Delete Records</a></br>";
				



}
  
?>


