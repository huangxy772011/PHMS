<!DOCTYPE html>

<html >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Varela" rel="stylesheet" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />

<link href="main.css" rel="stylesheet" type="text/css" media="screen and (min-width: 821px)" />
<link href="mobile.css" rel="stylesheet" type="text/css" media="screen and (max-width: 820px)" />
<!--[if IE 6]><link href="default_ie6.css" rel="stylesheet" type="text/css" /><![endif]-->

</head>
<body>
<div id="wrapper">
	<div id="header-wrapper">
	<div id="header" class="container">
		<div id="logo">
			<h1><a href="homepage.html">&nbsp;&nbsp;&nbsp;PHMS</a></h1>
		</div>
		<div id="menu">
			<ul>
				<li class="current_page_item"><a href="homepage.html" accesskey="1" title="">HOMEPAGE</a></li>
				<li><a href="newrecord.php" accesskey="2" title="">NEW RECORD</a></li>
				<li><a href="existing.php" accesskey="3" title="">UPDATE RECORD</a></li>
				<li><a href="manageinfo.php" accesskey="4" title="">SHOW RECORD</a></li>
				<li><a href="deleteReco.php" accesskey="5" title="">DELETE RECORD</a></li>
			</ul>
		</div>
	</div>
	</div>
	
</div>

<div id="banner">
 <div id="rt" class="container">
  
  <?php include 'delete.php';?>
  
  
  
  
  
  
  
</div>

</div>

<div class="figure">
	  <figure>
		<a href="#top"> <img src="img/back-to-top.png" alt="back to top" title="Top" width="50" height="50" />  </a>
	  </figure>
	  </div>

      <footer>
	    <p><a href="homepage.html">Home</a> | <a href="#">About</a> | <a href="#">Contact us</a> | <a href="#">Search</a></p>
        <p><em>Copyright &copy;  Company 2014</em></p>
      </footer>

</div>
</body>
</html>