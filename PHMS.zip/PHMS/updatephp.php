<?php
error_reporting(E_ALL);

ini_set('display_errors', 1);

$servername = "localhost";
$username = "root";
$password = "ycx2l0aYXLxH";
$dbname = "recordDB";

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
$nameErr = $emailErr = $phoneErr = $speciesErr = $genderErr = $websiteErr = $fileToUploadErr = $petnameErr = $neuterErr = $ageErr = $dateErr = "";
$name = $email = $phone = $species = $gender = $comment = $website = $fileToUpload = $petname = $neuter = $age= $date = $desc="";
#############Start retrieve data from DB by id
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	if (isset($_POST["id"])){
		if (!empty($_POST["id"])) {
		$id = test_input($_POST["id"]);
		}
		$conn = new mysqli($servername, $username, $password, $dbname);

		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		}

		$query  = "SELECT * FROM patient where id='$id'";
		$result = $conn->query($query);

		if (!$result) die ("Database access failed: " . $conn->error);

		$rows = $result->num_rows;
		for ($j = 0 ; $j < $rows ; ++$j) {
			$result->data_seek($j);
			$row = $result->fetch_array(MYSQLI_NUM);
			$myid = $row[0];
			$name = $row[1];
			$email = $row[2];
			$phone = $row[3];
			$species = $row[4];
			$petname = $row[5];
			$gender = $row[6];
			$neuter = $row[7];
			$age = $row[8];
			$date = $row[9];
			$desc = $row[10];
		}
		$result->close();
		$conn->close();
	}	
}



#############Validate input
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	if (isset($_POST["name"])){
		$myid = test_input($_POST["myid"]);
		if (empty($_POST["name"])) {
			$nameErr = "Owner name is required";
		} 
		else {
			$name = test_input($_POST["name"]);
			if (!preg_match("/^[a-zA-Z]*$/",$name)) {
				$nameErr = "Please enter only letters"; 
			}
		}
		
		if (empty($_POST["email"])) {
     $emailErr = "Email is required";
   } else {
     $email = test_input($_POST["email"]);
     if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
       $emailErr = "Invalid email address"; 
     }
   }
   
   if (empty($_POST["phone"])) {
     $phoneErr = "Phone number is required";
   } else {
     $phone = test_input($_POST["phone"]);
     if (!preg_match("/^[0-9]{10}$/", $phone)) {
       $phoneErr = "Invalid phone number"; 
     }
   }
   
   if(isset($_REQUEST["species"]) && $_REQUEST["species"] == "") { 
     $speciesErr = "Please select a species";
	 } 
	 else {
     $species = test_input($_POST["species"]);
   } 
   if (empty($_POST["gender"])) {
     $genderErr = "Gender is required";
   } else {
     $gender = $_POST["gender"];
   }
   
   if (empty($_POST["petname"])) {
     $petnameErr = "Pet name is required";
   } else {
     $petname = test_input($_POST["petname"]);
     // check if name only contains letters and whitespace
     if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
       $petnameErr = "Please enter only letters"; 
     }
   }
   if (empty($_POST["neuter"])) {
     $neuterErr = "Neuter info is required";
   } else {
     $neuter = test_input($_POST["neuter"]);
   }
   
    if  (empty($_POST["date"])) {
		$dateErr="";
  }
  elseif (!preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/",$_POST["date"])) {
       $dateErr = "Invalid date formate, only YYYY-MM-DD is accepted"; 
  }
  else{
		$date = test_input($_POST["date"]); 
   }
  
 
  if (!preg_match('/^[0-9]*(\.[0-9]+)?$/',$_POST["age"])) {
       $ageErr = "Invalid age formate, only integer and float are accepted"; 
     }
     else{
		$age = test_input($_POST["age"]); 
	 }
   
$desc = $_POST["desc"];		
#############If fail to validate, return 
		if ($nameErr!=""|| $emailErr != "" || $phoneErr !="" || $speciesErr !="" || $genderErr !="" || $petnameErr !="" || $neuterErr !="" || $ageErr != "" || $dateErr != ""  ){
			return;
		}	
#############Update data
		if ($name!="" || $email!= "" || $phone!="" || $species!="" || $gender!="" || $petname!="" || $neuter!=""){
			$conn = new mysqli($servername, $username, $password, $dbname);

			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			}
			$sql = "UPDATE patient SET Ownername='$name', Owneremail='$email', Ownerphone='$phone', Species='$species', Petname='$petname', Gender='$gender', Neutered='$neuter', Age='$age', VisitDate='$date', Description='$desc' WHERE id=$myid";
			
			
			
			if (mysqli_query($conn, $sql)) {
				echo '<script language="javascript">';
				echo 'alert("New record created successfully")';
				echo '</script>';
			} else {
				echo "  " . $sql . "<br>" . mysqli_error($conn);
			}	
			mysqli_close($conn);
		}	
	
	
	}
	
	
	
	

}
/*

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
if (empty($_POST["name"])) {
     $nameErr = "Owner name is required";
   } 
   else {
	 $name = test_input($_POST["name"]);
     if (!preg_match("/^[a-zA-Z]*$/",$name)) {
       $nameErr = "Please enter only letters"; 
     }
   }
   
   if (empty($_POST["email"])) {
     $emailErr = "Email is required";
   } else {
     $email = test_input($_POST["email"]);
     if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
       $emailErr = "Invalid email address"; 
     }
   }
   
   if (empty($_POST["phone"])) {
     $phoneErr = "Phone number is required";
   } else {
     $phone = test_input($_POST["phone"]);
     if (!preg_match("/^[0-9]{10}$/", $phone)) {
       $phoneErr = "Invalid phone number"; 
     }
   }
   
   if(isset($_REQUEST["species"]) && $_REQUEST["species"] == "") { 
     $speciesErr = "Please select a species";
	 } 
	 else {
     $species = test_input($_POST["species"]);
   } 
   
    $target_dir = "uploads/";
	$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
	$uploadOk = 1;
	$imageFile =  pathinfo($target_file,PATHINFO_EXTENSION);
	$imageFileType = strtolower($imageFile);
   if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
    $fileToUploadErr = "Please upload only image file. Only JPG, JPEG, PNG & GIF files are allowed";
    $uploadOk = 0;
       }
	  

   if (empty($_POST["gender"])) {
     $genderErr = "Gender is required";
   } else {
     $gender = $_POST["gender"];
   }
   
   if (empty($_POST["petname"])) {
     $petnameErr = "Pet name is required";
   } else {
     $petname = test_input($_POST["petname"]);
     // check if name only contains letters and whitespace
     if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
       $petnameErr = "Please enter only letters"; 
     }
   }
   if (empty($_POST["neuter"])) {
     $neuterErr = "Neuter info is required";
   } else {
     $neuter = test_input($_POST["neuter"]);
   }

$breed = $_POST["breed"];
$color = $_POST["color"];
$weight = $_POST["weight"];
$age = $_POST["age"];
$date = $_POST["date"];
$desc = $_POST["desc"];


if ($nameErr!="" || $emailErr != "" || $phoneErr !="" || $speciesErr !="" || $genderErr !="" || $petnameErr !="" || $neuterErr !="" ){
	return;
}


$sql = "UPDATE p_info SET Ownername='$name', Owneremail='$email', Ownerphone='$phone', Photo='$fileToUpload', Species='$species', Petname='$petname', Breed='$breed', Color='$color', Gender='$gender', Neutered='$neuter', Weight='$weight', Age='$age', VisitDate='$date', Description='$desc', where id='$id'";	
	
}
function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
/*
   if (empty($_POST["name"])) {
     $nameErr = "Name is required";
   } else {
     $name = test_input($_POST["name"]);
     if (!preg_match("/^[a-zA-Z]*$/",$name)) {
       $nameErr = "Please enter only letters"; 
     }
     else{
      $submit++;
     }
   }
   if (empty($_POST["email"])) {
     $emailErr = "Email is required";
   } else {
     $email = test_input($_POST["email"]);
     if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
       $emailErr = "Invalid email address"; 
     }
     else{
      $submit++;
     }
   }
   
   if (empty($_POST["phone"])) {
     $phoneErr = "Phone number is required";
   } else {
     $lastname = test_input($_POST["phone"]);
     if (!preg_match("/^[0-9]{10}$/", $phone)) {
       $phoneErr = "Invalid phone number"; 
     }
     else{
      $submit++;
     }
   }
   
   if(isset($_REQUEST["species"]) && $_REQUEST["species"] == "") { 
     $speciesErr = "Please select a species";
	 } 
	 else {
     $species = test_input($_POST["species"]);
	 $submit++;
   } 
   
    $target_dir = "uploads/";
	$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
	$uploadOk = 1;
	$imageFile =  pathinfo($target_file,PATHINFO_EXTENSION);
	$imageFileType = strtolower($imageFile);
   if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
    $fileToUploadErr = "Please upload only image file. Only JPG, JPEG, PNG & GIF files are allowed";
    $uploadOk = 0;
       }
	  

   if (empty($_POST["gender"])) {
     $genderErr = "Gender is required";
   } else {
     $gender = $_POST["gender"];
	 $submit++;
   }
   
   if (empty($_POST["petname"])) {
     $petnameErr = "Pet name is required";
   } else {
     $petname = test_input($_POST["petname"]);
     // check if name only contains letters and whitespace
     if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
       $petnameErr = "Please enter only letters"; 
     }
	 else{
		 $submit++;
	 }
   }
   if (empty($_POST["neuter"])) {
     $neuterErr = "Neuter info is required";
   } else {
     $neuter = test_input($_POST["neuter"]);
	 $submit++;
   }

   
   if($submit == 7){
    $sql = "UPDATE p_info SET Ownername='$name', Owneremail='$email', Ownerphone='$phone', Photo='$fileToUpload', Species='$species', Petname='$petname', Breed='$breed', Color='$color', Gender='$gender', Neutered='$neuter', Weight='$weight', Age='$age', VisitDate='date', Description='$desc', where id='$id'";
    
   }
}

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}






if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "  " . $sql . "<br>" . mysqli_error($conn);
}



mysqli_close($conn);
*/

?>