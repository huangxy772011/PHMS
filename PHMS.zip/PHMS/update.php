<!DOCTYPE html>
<html>
<head lang="en">
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   
   <meta name="description" content="">
   <meta name="author" content="">
   <link rel="icon" href="../../favicon.ico">
   <title>Existing Record</title>
   <link href="bootstrap-3.3.5/docs/dist/css/bootstrap.min.css" rel="stylesheet">
   <link href="bootstrap-3.3.5/docs/examples/jumbotron/jumbotron.css" rel="stylesheet">
   
   <script src="bootstrap-3.3.5/docs/assets/js/ie-emulation-modes-warning.js"></script>
   
   
   <link rel="stylesheet" href="PHMS.css" />
   <link href='http://fonts.googleapis.com/css?family=Lobster'
rel='stylesheet' type='text/css'>
   <link href='http://fonts.googleapis.com/css?family=Lato'
rel='stylesheet' type='text/css'>
   <style>
	.error {color: #FF0000;}
   </style>
</head>
<body>
	<nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="homepage.html">Pet Hospital Management System</a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li><a href="homepage.html">Home</a></li>
            <li role="presentation" class="dropdown active">
				<a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
					Record <span class="caret"></span>
				</a>
				<ul class="changeDropDown dropdown-menu">
				<a class="dropDown" href="newrecord.php">New Record</a><br/><br/>
				<a class="dropDown" href="existing.php">Update Record</a>
				</ul></li>
            <li><a href="manageinfo.php">Show Record</a></li>
			<li><a href="deleteReco.php">Delete Record</a></li>
			
			
			
			
          </ul>
        </div><!--/.nav-collapse -->
      </div>
	 </nav>

<div class="container">
<?php include 'updatephp.php';?>

<form method="post" id="form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  <h2>Update Records:</h2>
  <fieldset>
  </br>
		<p>
			<label for="Ownername">Owner name *</label><br/>
			<input type="text" name="name" value="<?php echo $name;?>">
			<input type="hidden" name="myid" value="<?php echo $myid;?>">
			<span class="error"> <?php echo $nameErr;?></span>
		</p>
		
		<p>
            <label for="Owneremail">Owner email * <em>(eg. xx@xx.xx)</em></label><br/>
			<input type="text" name="email" value="<?php echo $email;?>">
			<span class="error"> <?php echo $emailErr;?></span>
		</p>
		 
		<p>
            <label for="Ownernumber">Owner phone number * <em>(10 digit only)</em></label><br/>
			<input type="text" name="phone" value="<?php echo $phone;?>">
			<span class="error"> <?php echo $phoneErr;?></span>
		</p>
		 
		<!--	<br/>
				<div class="form-group">
					<label for="inputFile">Patient photo: <em>(only picture file can be accepted)</em></label>
					<input type="file" name="pic" id="inputFile" accept="image/*">
					<p class="help-block"> Please choose your patient photo.</p>
					
				</div>   -->
	 
         <p>
            <label>Species: *</label><br/>
			
			<select name="species">
			 <option value="" >None</option>
			 <option value="cat" <?php if (isset($species) && $species=="cat") echo "selected";?>>Feline (cat)</option>
			 <option value="dog" <?php if (isset($species) && $species=="dog") echo "selected";?>>Canis (dog)</option>
             <option value="small" <?php if (isset($species) && $species=="small") echo "selected";?>>Small mammal (guinea pig, hamster, rabbit, etc.) </option>
	   	     <option value="exotic" <?php if (isset($species) && $species=="exotic") echo "selected";?>>Exotic pet (reptile, bird, etc.)</option>
			 <option value="other" <?php if (isset($species) && $species=="other") echo "selected";?>>Other species </option>
            </select> 
            <span class="error"> <?php echo $speciesErr;?></span>
         </p>
		 <br/>
		 <p>
            <label for="name">Pet Name *</label><br/>
			<input type="text" name="petname" id="petname" size="30" class="required" value="<?php echo $petname;?>">
			<span class="error"> <?php echo $petnameErr;?></span>
         </p>
		 
		 
		 <p>
            <label>Gender: *</label><br/>
			<input type="radio" name="gender" <?php if (isset($gender) && $gender=="female") echo "checked";?>  value="female">Female
			<input type="radio" name="gender" <?php if (isset($gender) && $gender=="male") echo "checked";?>  value="male">Male &nbsp;
			<span class="error"> <?php echo $genderErr;?></span>
         </p>
		 
		 <p>
            <label>Has been neutered: *</label><br/>
            <input type="radio" name="neuter" <?php if (isset($neuter) && $neuter=="yes") echo "checked";?>  value="yes">Yes<br/>
			<input type="radio" name="neuter" <?php if (isset($neuter) && $neuter=="no") echo "checked";?>  value="no">No<br/>
			<span class="error"> <?php echo $neuterErr;?></span>
         </p>
		 
		 
		 <p>
            <label>Age: </label><br/>
		    <input type="text" name="age" id="ageY" size="8" value="<?php echo $age;?>"/>
			year(s)
         </p>
		 
		 <p>
            <label>Visit date: </label><br/>
		    <input type="text" name="date" value="<?php echo $date;?>"/>
         </p>
		 
		 <p>
			<label>Description: </label><br/>
			<textarea name="desc" placeholder="enter a description" rows="4" cols="30" ><?php echo $desc;?></textarea>
		 </p>
		 
		 
<br><br>

   <input type="submit" name="submit" value="submit"> 
   </fieldset>
</form>
</div>
<hr>
	   <div class="figure">
		<figure>
			<a href="#top"> <img src="back-to-top.png" alt="back to top" title="Top" width="50" height="50" />  </a>
		</figure>
	  </div>
	   <footer>
	    <p><a href="homepage.html">Home</a> | <a href="#">About</a> | <a href="#">Contact us</a> | <a href="#">Search</a></p>
        <p><em>Copyright &copy;  Company 2014</em></p>
      </footer>
	 </div>
</body>
<!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="bootstrap-3.3.5/docs/dist/js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="bootstrap-3.3.5/docs/assets/js/ie10-viewport-bug-workaround.js"></script>	
</html>