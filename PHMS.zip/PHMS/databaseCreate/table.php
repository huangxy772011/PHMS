<?php
$servername = "localhost";
$username = "root";
$password = "ycx2l0aYXLxH";
$dbname = "recordDB";

// Create connection
 $conn = mysqli_connect($servername, $username, $password, $dbname);
 // Check connection
 if (!$conn) {
     die(" Connection failed: " . mysqli_connect_error());
}

		// sql to create table
 $sql = "CREATE TABLE patient (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
Ownername VARCHAR(30) NOT NULL,
Owneremail VARCHAR(50) NOT NULL,
Ownerphone VARCHAR(30) NOT NULL,
Species VARCHAR(100) NOT NULL,
Petname VARCHAR(50) NOT NULL,
Gender VARCHAR(30),
Neutered VARCHAR(30) NOT NULL,
Age VARCHAR(30),
Visitdate VARCHAR(30),
Description TEXT
)";

if (mysqli_query($conn, $sql)) {
    echo " Table name created successfully. ";
} else {
    echo " Error creating table: " . mysqli_error($conn);
}

echo " Connected successfully. ";
mysqli_close($conn);
 ?>