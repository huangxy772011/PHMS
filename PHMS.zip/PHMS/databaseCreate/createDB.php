<?php
$servername = "localhost";
$username = "root";
$password = "ycx2l0aYXLxH";
$dbname = "db2";

// Create connection
 $conn = mysqli_connect($servername, $username, $password);
 // Check connection
 if (!$conn) {
     die(" Connection failed: " . mysqli_connect_error());
}

// Create database
 $sql = "CREATE DATABASE " .$dbname;
 if (mysqli_query($conn, $sql)) {
    echo " Database created successfully. ";
} else {
    echo " Error creating database: " . mysqli_error($conn);
}
// Close connection then reopen with $dbname
mysqli_close($conn);
$conn = mysqli_connect($servername, $username, $password, $dbname);
		// Check connection
 if (!$conn) {
     die(" Connection failed: " . mysqli_connect_error());
}

		// sql to create table
 $sql = "CREATE TABLE p_info (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
Ownername VARCHAR(30) NOT NULL,
Owneremail VARCHAR(50) NOT NULL,
Ownerphone VARCHAR(30) NOT NULL,
Photo LONGBLOB NOT NULL,
Species VARCHAR(100) NOT NULL,
Petname VARCHAR(50) NOT NULL,
Breed VARCHAR(50),
Color VARCHAR(50),
Gender VARCHAR(30),
Neutered VARCHAR(30) NOT NULL,
Weight VARCHAR(30),
Age VARCHAR(30),
Visitdate TIMESTAMP,
Description TEXT
)";

if (mysqli_query($conn, $sql)) {
    echo " Table db2 created successfully. ";
} else {
    echo " Error creating table: " . mysqli_error($conn);
}

echo " Connected successfully. ";
mysqli_close($conn);
 ?>