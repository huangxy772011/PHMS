<?php
error_reporting(E_ALL);

ini_set('display_errors', 1);

$servername = "localhost";
$username = "root";
$password = "ycx2l0aYXLxH";
$dbname = "recordDB";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
}


$query  = "SELECT * FROM patient";
$result = $conn->query($query);

if (!$result) die ("Database access failed: " . $conn->error);

$rows = $result->num_rows;
for ($j = 0 ; $j < $rows ; ++$j) {
    $result->data_seek($j);
    $row = $result->fetch_array(MYSQLI_NUM);

    echo <<<_END
    <p>
      Owner name: $row[1]<br/>
	  Owner email: $row[2]<br/>
      Owner phone number: $row[3]<br/>
      Species: $row[4]<br/>
      Pet name: $row[5]<br/>
	  Gender: $row[6]<br/>
	  Neutered: $row[7]<br/>
	  Age (years): $row[8]<br/>
	  Visit date: $row[9]<br/>
	  Description: $row[10] <br/>
    <form action="update.php" method="post">
    <input type="submit" value="Update">
	<br/><br/>
    <input type="hidden" name="delete" value="yes">
    <input type="hidden" name="Ownername" value="$row[1]">
    <input type="hidden" name="Owneremail" value="$row[2]">
    <input type="hidden" name="Ownerphone" value="$row[3]">
	<input type="hidden" name="Species" value="$row[4]">
    <input type="hidden" name="Petname" value="$row[5]">
	<input type="hidden" name="Gender" value="$row[6]">
	<input type="hidden" name="Neutered" value="$row[7]">
	<input type="hidden" name="Age" value="$row[8]">
	<input type="hidden" name="Visitdate" value="$row[9]">
	<input type="hidden" name="Description" value="$row[10]">
	<input type="hidden" name="id" value="$row[0]">
</form>
    </p>
_END;
}

$result->close();



$conn->close();

function get_post($conn, $var) {
  return $conn->real_escape_string($_POST[$var]);
}

?>