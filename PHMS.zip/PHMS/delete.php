<?php
error_reporting(E_ALL);

ini_set('display_errors', 1);

$servername = "localhost";
$username = "root";
$password = "ycx2l0aYXLxH";
$dbname = "recordDB";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['delete']) && isset($_POST['id'])) {

  $id = get_post($conn, 'id');

    $query  = "DELETE FROM patient WHERE id='$id'";

    $result = $conn->query($query);

    if (!$result) {
      echo "DELETE failed: $query <br />" . $conn->error . "<br /><br />";
    } 

    echo "<h2>Delete Records:</h2>";
}

$query  = "SELECT * FROM patient";
$result = $conn->query($query);

if (!$result) die ("Database access failed: " . $conn->error);

$rows = $result->num_rows;
for ($j = 0 ; $j < $rows ; ++$j) {
    $result->data_seek($j);
    $row = $result->fetch_array(MYSQLI_NUM);

    echo <<<_END
	<p>Owner name: $row[1]<br/>
		Owner email: $row[2]<br/>
		Owner phone number: $row[3]<br/>
		Species: $row[4]<br/>
      	Pet name: $row[5]<br/>
	  	Gender: $row[6]<br/>
	  	Neutered: $row[7]<br/>
	  	Age (years): $row[8]<br/>
	  	Visit date: $row[9]<br/>
	  	Description: $row[10]<br/>
		<form action="deleteReco.php" method="post">
    <input type="hidden" name="delete" value="yes">
    <input type="hidden" name="id" value="$row[0]">
    <input type="submit" value="DELETE"></form><br/><br/>

	</p>
	
   
_END;
}

$result->close();



$conn->close();

function get_post($conn, $var) {
  return $conn->real_escape_string($_POST[$var]);
}

?>